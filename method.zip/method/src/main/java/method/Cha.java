package method;

// Cha.java
public class Cha extends BebidaQuente {
    @Override
    protected void adicionarIngrediente() {
        System.out.println("Adicionando o saquinho de cha.");
    }
}
