package method;

// Cafe.java
public class Cafe extends BebidaQuente {
    @Override
    protected void adicionarIngrediente() {
        System.out.println("Adicionando o po de cafe.");
    }
}
